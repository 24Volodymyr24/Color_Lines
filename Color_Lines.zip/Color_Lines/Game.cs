﻿using Color_Lines.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Color_Lines.Memento;

namespace Color_Lines
{
    public class Game
    {
        private Field _field;
        private int _moveCounter = 0;
        private Label _moveCount;
        public Caretaker ct{get;set;}
        public Game(ref Field f, ref Label moveCount)
        {
            _field = f;
            _moveCounter = 0;
            _moveCount = moveCount;
            _moveCount.Text = $"Количеаство ходов: {_moveCounter}";
            ct=new Caretaker();
        }
        public void PictureBoxClickHandler(int x,int y)
        {
            var currenCell = FindCellOnBoardByCoords(x, y);
            if(currenCell.Piece!=null)
            {
                if(GetActiveCell()!=null)
                {
                    GetActiveCell().IsActive = false;
                    currenCell.IsActive = true;
                }
                else
                {
                    currenCell.IsActive = true;
                }
            }
            else
            {
                if(GetActiveCell()!=null)
                {
                    if(IfCanGoInThisCell(currenCell))
                    {
                        currenCell.Piece=GetActiveCell().Piece;
                        GetActiveCell().Piece = null;
                        GetActiveCell().IsActive = false;
                        currenCell.Piece.X = currenCell.X;
                        currenCell.Piece.Y = currenCell.Y;
                        Memento.Memento newMoment = new Memento.Memento(_field, _moveCounter);
                        ct.AddMemento(newMoment);
                        _moveCounter++;
                         try
                        {
                            _field.AddPieces();
                        }
                        catch(ArgumentException)
                        {
                            MessageBox.Show("Невозможно добавить новые фигуры!","Игра окончена!");
                        }
                    }
                }
            }
            if(_field.GetEmptyCells().Count<3)
                MessageBox.Show("Невозможно добавить новые фигуры!", "Игра окончена!");
            _moveCount.Text = $"Количеаство ходов: {_moveCounter}";
            FindAndDestroyLines();
           
           
            Drawer.DrawField(_field);
        }

        private Cell FindCellOnBoardByCoords(int x, int y)
        {
            for (int i = 0; i < Field.SIZE; i++)
            {
                for (int j = 0; j < Field.SIZE; j++)
                {
                    if (_field[i, j].X <= x && 
                        _field[i, j].X + _field[i, j].Size >= x && 
                        _field[i, j].Y <= y && 
                        _field[i, j].Y + _field[i, j].Size >= y)
                        return _field[i, j];
                }
            }
            return null;
        }


        private Cell GetActiveCell()
        {
            for (int i = 0; i < Field.SIZE; i++)
            {
                for (int j = 0; j < Field.SIZE; j++)
                {
                    if (_field[i, j].IsActive)
                        return _field[i,j];
                }
            }
            return null;
        }

        private bool IfCanGoInThisCell(Cell c)
        {
            List<Cell> possibleMoves = new List<Cell>();
            possibleMoves.Add(GetActiveCell());
            possibleMoves = CheckAround(possibleMoves);
            for (int i = 0; i < possibleMoves.Count; i++)
            {
                if (possibleMoves[i].XIndex == c.XIndex && possibleMoves[i].YIndex == c.YIndex)
                    return true;
            }
            return false;            
        }

       private List<Cell> CheckAround(List<Cell> moves)
        {
            List<Cell> oldMoves = new List<Cell>(moves);
            for (int i = 0; i < moves.Count; i++)
            {
                if (moves[i].XIndex + 1 < Field.SIZE &&
                    _field[moves[i].XIndex + 1, moves[i].YIndex].Piece is null)
                {
                    int counter = 0;
                    for (int j = 0; j < moves.Count; j++)
                    {
                        if (moves[j].XIndex == moves[i].XIndex + 1 && moves[j].YIndex == moves[i].YIndex)
                            counter++;
                    }
                    if (counter == 0)
                        moves.Add(_field[moves[i].XIndex + 1, moves[i].YIndex]);
                }
                if (moves[i].XIndex - 1 >= 0 &&
                   _field[moves[i].XIndex - 1, moves[i].YIndex].Piece is null)
                {
                    int counter = 0;
                    for (int j = 0; j < moves.Count; j++)
                    {
                        if (moves[j].XIndex == moves[i].XIndex - 1 && moves[j].YIndex == moves[i].YIndex)
                            counter++;
                    }
                    if (counter == 0)
                        moves.Add(_field[moves[i].XIndex - 1, moves[i].YIndex]);
                }
                if (moves[i].YIndex + 1 < Field.SIZE &&
                   _field[moves[i].XIndex, moves[i].YIndex + 1].Piece is null)
                {
                    int counter = 0;
                    for (int j = 0; j < moves.Count; j++)
                    {
                        if (moves[j].XIndex == moves[i].XIndex && moves[j].YIndex  == moves[i].YIndex+1)
                            counter++;
                    }
                    if (counter == 0)
                        moves.Add(_field[moves[i].XIndex, moves[i].YIndex + 1]);
                }
                if (moves[i].YIndex - 1 >= 0 &&
                _field[moves[i].XIndex, moves[i].YIndex - 1].Piece is null)
                {
                    int counter = 0;
                    for (int j = 0; j < moves.Count; j++)
                    {
                        if (moves[j].XIndex == moves[i].XIndex && moves[i].YIndex - 1 == moves[j].YIndex)
                            counter++;
                    }
                    if (counter == 0)
                        moves.Add(_field[moves[i].XIndex, moves[i].YIndex - 1]);
                }
                if (oldMoves.Count == moves.Count)
                    return moves;
                else CheckAround(moves);
            }
            return moves;
        }

        private void FindAndDestroyLines()
        {
            var cellWithPiecesToDestroy = new List<Cell>();
            for(int i=0;i<Field.SIZE;i++)
            {
                for(int j=0;j<Field.SIZE-1;j++)
                {
                    if (_field[i, j + 1].Piece!=null &&
                        _field[i, j].Piece!=null &&
                        _field[i,j].Piece.MyColor== _field[i, j+1].Piece.MyColor)
                    {
                        if(cellWithPiecesToDestroy.Count==0)
                        cellWithPiecesToDestroy.Add(_field[i, j]);
                        cellWithPiecesToDestroy.Add(_field[i, j+1]);
                    }
                    else
                    {
                        if(cellWithPiecesToDestroy.Count>=5)
                        {
                            foreach (var item in cellWithPiecesToDestroy)
                                item.Piece = null;
                        }
                        cellWithPiecesToDestroy = new List<Cell>();
                    }
                }
            }
            for (int i = 0; i < Field.SIZE; i++)
            {
                for (int j = 0; j < Field.SIZE - 1; j++)
                {
                    if (_field[j+1,i].Piece != null &&
                        _field[j,i].Piece != null &&
                        _field[j,i].Piece.MyColor == _field[j+1,i].Piece.MyColor)
                    {
                        if (cellWithPiecesToDestroy.Count == 0)
                            cellWithPiecesToDestroy.Add(_field[j,i]);
                        cellWithPiecesToDestroy.Add(_field[j+1,i]);
                    }
                    else
                    {
                        if (cellWithPiecesToDestroy.Count >= 5)
                        {
                            foreach (var item in cellWithPiecesToDestroy)
                                item.Piece = null;
                        }
                        cellWithPiecesToDestroy = new List<Cell>();
                    }
                }
            }
        }

        public void MoveBack()
        {
            var m = ct.PickMemento();
            _field = m.Field;
            _moveCounter = m.Move;
            _moveCount.Text = $"Количеаство ходов: {_moveCounter}";
            Drawer.DrawField(m.Field);

        }

    }
}
