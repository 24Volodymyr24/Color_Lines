﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Color_Lines.Model
{
    public class Field : ICloneable
    {
        private Cell[,] field;
        public PictureBox MyPictureBox { get; set; }

        public const int SIZE = 9;

        public Cell this[int index1, int index2]
        {
            get
            {
                return field[index1, index2];
            }
            private set
            {
                 field[index1, index2]=value;
            }
        }

        public Field(PictureBox myPictureBox)
        {
            MyPictureBox = myPictureBox ?? throw new ArgumentNullException("Элемент PictureBox не может быть null");
            if (MyPictureBox.Width != MyPictureBox.Height)
                MyPictureBox.Width = MyPictureBox.Height;
            int cellSize = MyPictureBox.Width / SIZE;
            field = new Cell[SIZE, SIZE];
            for (int i = 0; i < field.GetLength(0); i++)
            {
                for (int j = 0; j < field.GetLength(1); j++)
                {
                    field[i, j] = new Cell(cellSize * i, cellSize * j, cellSize, i, j, null);
                }
            }
            AddPieces();
        }

        public List<Cell> GetEmptyCells()
        {
            var emptyCells = new List<Cell>();
            for (int i = 0; i < field.GetLength(0); i++)
            {
                for (int j = 0; j < field.GetLength(1); j++)
                {
                    if (field[i, j].Piece is null)
                        emptyCells.Add(field[i,j]);
                }
            }
            return emptyCells;
        }

        public void AddPieces()
        {
            var emptyCells=GetEmptyCells();
            if (emptyCells.Count < 3)
                throw new ArgumentException("New pieces can`t be added");
            Random r =new Random();
            for(int i=0;i<3;i++)
            {
                Cell currentCell = emptyCells[r.Next(emptyCells.Count)];
                currentCell.Piece = new Piece(currentCell.X, currentCell.Y, currentCell.Size, Piece.PossibleColors[r.Next(7)]);
                emptyCells.Remove(currentCell);
            }
        }

        public object Clone()
        {
            var newField = new Field(MyPictureBox);
            for (int i = 0; i < Field.SIZE; i++)
            {
                for (int j = 0; j < Field.SIZE; j++)
                {
                    newField[i, j] = (Cell)field[i, j].Clone();
                }
            }
            return newField;
        }
    }
}
