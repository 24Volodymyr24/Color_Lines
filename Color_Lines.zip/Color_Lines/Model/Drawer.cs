﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Color_Lines.Model
{
    public static class Drawer
    {
        public static void DrawPiece(Piece p, Graphics g)
        {
            const int COEFFICIENT = 7;
            double x = p.X + p.Size / COEFFICIENT;
            double y = p.Y + p.Size / COEFFICIENT;
            double size = p.Size * 5 / COEFFICIENT;
            Brush b = new SolidBrush(p.MyColor);
            g.FillEllipse(b, (float)x, (float)y, (float)size, (float)size);
        }

        public static void DrawCell(Cell c, Graphics g)
        {
            Brush b = new SolidBrush(c.MyColor);
            g.FillRectangle(b, c.X, c.Y, c.Size, c.Size);
            g.DrawLine(new Pen(new SolidBrush(Color.White)), c.X, c.Y, c.X + c.Size, c.Y);
            g.DrawLine(new Pen(new SolidBrush(Color.White)), c.X + c.Size, c.Y + c.Size, c.X , c.Y + c.Size);
            g.DrawLine(new Pen(new SolidBrush(Color.White)), c.X + c.Size, c.Y, c.X + c.Size, c.Y + c.Size);
            g.DrawLine(new Pen(new SolidBrush(Color.White)), c.X, c.Y, c.X, c.Y + c.Size);
            if (c.IsActive)
                g.FillRectangle(new SolidBrush(Color.FromArgb(70, 0, 255, 84)), c.X, c.Y, c.Size, c.Size);
        }

        public static void DrawField(Field f)
        {
            Bitmap bmp = new Bitmap(f.MyPictureBox.Width, f.MyPictureBox.Height);
            Graphics g = Graphics.FromImage(bmp);
            g.Clear(f.MyPictureBox.BackColor);

            for (int i = 0; i < Field.SIZE; i++)
            {
                for (int j = 0; j < Field.SIZE; j++)
                {
                    DrawCell(f[i, j], g);
                    if (f[i, j].Piece != null)
                    {
                        DrawPiece(f[i, j].Piece, g);
                    }
                }
            }
            f.MyPictureBox.Image = bmp;
        }
    }
}
