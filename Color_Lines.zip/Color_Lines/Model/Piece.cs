﻿using System;
using System.Collections.Generic;
using System.Drawing;


namespace Color_Lines.Model
{
    public class Piece :ICloneable
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Size { get; set; }
        public Color MyColor { get; set; }
        public static readonly Dictionary<int, Color> PossibleColors = new Dictionary<int, Color>()
        {
            { 0,Color.Red },
            { 1,Color.Yellow},
            { 2,Color.DarkBlue},
            { 3,Color.LightBlue},
            { 4,Color.Pink},
            { 5,Color.Green},
            { 6,Color.Black }
        };
        public Piece(int x, int y, int size, Color color)
        {
            X = x;
            Y = y;
            Size = size;
            MyColor = color;
        }

        public object Clone()
        {
            return new Piece(X,Y,Size,MyColor);
        }
    }
}
