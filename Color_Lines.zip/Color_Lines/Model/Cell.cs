﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Color_Lines.Model
{
    public class Cell: ICloneable
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Size { get; set; }
        public int XIndex { get; set; }
        public int YIndex { get; set; }
        public Color MyColor { get; set; }
        public bool IsActive { get; set; } = false;
        public Piece Piece { get; set; } = null;
        public Cell(int x, int y, int size, int xIndex, int yIndex, Piece piece)
        {
            X = x;
            Y = y;
            Size = size;
            XIndex = xIndex;
            YIndex = yIndex;
            MyColor = Color.DarkCyan;
            Piece = piece;
            Size = size;
            
        }

        public object Clone()
        {
            return new Cell(X, Y, Size, XIndex, YIndex, Piece!=null?(Piece)Piece.Clone():null) {IsActive=IsActive, MyColor=MyColor};
        }
    }
}
