﻿using Color_Lines.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Color_Lines
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            field = new Model.Field(this.pictureBox1);
            game = new Game(ref field, ref label1);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            game.PictureBoxClickHandler(e.X,e.Y);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            field = new Field(pictureBox1);
            game = new Game(ref field,ref label1);
            Drawer.DrawField(field);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                game.MoveBack();
            }
            catch(NullReferenceException ex)
            { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Drawer.DrawField(field);
        }
    }
}
