﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Color_Lines.Model;
using System.Runtime.CompilerServices;

namespace Color_Lines.Memento
{
    public class Memento
    {
        public Field Field { get; }
        public int Move { get; }
        public Memento(Field f, int move)
        {
            Field = (Field)f.Clone();
            Move = move;
        }
    }
}
